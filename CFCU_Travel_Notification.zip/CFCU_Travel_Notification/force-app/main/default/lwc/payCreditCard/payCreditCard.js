import {LightningElement, wire} from 'lwc';
import schedulePayment from '@salesforce/apex/PayCreditCardHandler.schedulePayment';
import updatePaymentSourceInfo from '@salesforce/apex/PayCreditCardHandler.updatePaymentSourceInfo';
import getCreditCardsCardSummary from '@salesforce/apex/PayCreditCardHandler.getCreditCardsCardSummary';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {CurrentPageReference} from 'lightning/navigation';

export default class PayCreditCard extends LightningElement {
    creditCards = [];
    selectedCard = '';
    dueDate = '';
    cardNumber = '';
    lastPaymentDate = '';
    lastPaymentAmount = '';
    scheduledAutoPayAmount = '';
    scheduledOneTimeAmount = '';
    currentBalance = '';
    statementBalance = '';
    minimumPayment = '';
    routingNumber = '';
    checkingAccountNumber = '';
    autoPayEnabled = '';
    isOtherAmountSelected = false;
    isHome = true;
    isEditPaymentSource = false;
    isSchedulePayment = false;
    isCancelOutstandingPayment = false;
    paymentAmount = '';
    paymentDate = '';
    otherAmount = '';
    newRoutingNumber = '';
    newCheckingAccountNumber = '';

    get isCardSelected() {
        return this.selectedCard !== '';
    }

    @wire(CurrentPageReference) currentPageReference;

    get recordId() {
        return this.currentPageReference && this.currentPageReference.state.recordId;
    }
    get isEnterAmountDisabled() {
        return !this.isOtherAmountSelected;
    }

    @wire(getCreditCardsCardSummary, {
        MemberAccountId: '$recordId'
    })
    wiredCreditCards({
        error,
        data
    }) {
        if (data) {
            this.creditCards = data.map(card => {
                const cardDetails = this.parseCardDetails(card);
                return {
                    label: 'xxxx xxxx xxxx ' + cardDetails.cardNumber.slice(-4),
                    value: cardDetails.cardNumber,
                    ...cardDetails
                };
            });
        } else if (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error loading credit card details',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        }
    }

    parseCardDetails(card) {
        const parts = card.split(' ');
        return {
            cardNumber: parts[1],
            dueDate: this.formatDate(parts[3]),
            lastPaymentDate: this.formatDate(parts[5]),
            lastPaymentAmount: this.formatAmount(parts[7]),
            statementBalance: this.formatAmount(parts[9]),
            minimumPayment: this.formatAmount(parts[11]),
            currentBalance: this.formatAmount(parts[13]),
            checkingAccountNumber: parts[15],
            routingNumber: parts[17],
            scheduledAutoPayAmount: this.formatAmount(parts[19]),
            scheduledOneTimeAmount: this.formatAmount(parts[21]),

        };
    }

    formatAmount(amount) {
        if (amount === 'N/A') {
            return amount;
        }
        const num = parseFloat(amount.replace(/^0+/, ''));
        return isNaN(num) ? '' : `$${num.toFixed(2)}`;
    }

    formatDate(date) {
        if (date === '000000') {
            return 'N/A';
        }
        const [month, day, year] = date.split('-');
        const formattedYear = `20${year}`;
        return `${month}/${day}/${formattedYear}`;
    }

    formatLastPaymentDate(date) {
        const [year, month, day] = date.split('-');
        return `${month}/${day}/${year}`;
    }

    handleRadioChange(event) {
        const selectedValue = event.target.value;
        if (selectedValue === 'otherAmount') {
            this.isOtherAmountSelected = true;
        } else {
            this.isOtherAmountSelected = false;
        }
    }

    handleEditPaymentSource() {
        if (this.isCardSelected) {
            this.isHome = false;
            this.isEditPaymentSource = true;
        } else {
            this.showWarningMessage('Please choose a card from the dropdown menu before continuing with this action.');
        }
    }

    handleAmountChange(event) {
        let enteredAmount = event.target.value;
        const amountPattern = /^\d+(\.\d{0,5})?$/;
        if (amountPattern.test(enteredAmount)) {
            if (enteredAmount.includes('.')) {
                const [integerPart, decimalPart] = enteredAmount.split('.');
                if (decimalPart.length > 2) {
                    enteredAmount = `${integerPart}.${decimalPart.slice(0, 2)}`;
                    event.target.value = enteredAmount;
                }
            }
        } else {
            this.showErrorMessage('Please enter a valid Amount ');
            event.target.value = '';
        }
    }

    cancel() {
        this.isHome = true;
        this.isEditPaymentSource = false;
    }

    handleRoutingNumberChange(event) {
        const value = event.target.value;
        const numberPattern = /^\d*$/;
        if (!numberPattern.test(value)) {
            this.showWarningMessage('Only numbers are allowed in the Routing Number field.');
            event.target.value = '';
        } else if (value.length !== 9) {
            this.showWarningMessage('Routing Number must be exactly 9 digits.');
        } else {
            this.newRoutingNumber = value;
        }
    }

    handleConfirmRoutingNumberChange(event) {
        const confirmRoutingNumber = event.target.value;
        if (this.newRoutingNumber !== confirmRoutingNumber) {
            this.showErrorMessage('Routing numbers do not match');
        } else {
            this.routingNumber = confirmRoutingNumber;
        }
    }

    handleAccountNumberChange(event) {
        const value = event.target.value;
        const numberPattern = /^\d*$/;
        if (!numberPattern.test(value)) {
            this.showWarningMessage('Only numbers are allowed in the Account Number field.');
            event.target.value = '';
        } else if (value.length !== 17) {
            this.showWarningMessage('Account Number must be exactly 17 digits.');
        } else {
            this.newCheckingAccountNumber = value;
        }
    }

    handleConfirmAccountNumberChange(event) {
        const confirmAccountNumber = event.target.value;
        if (this.newCheckingAccountNumber !== confirmAccountNumber) {
            this.showErrorMessage('Account numbers do not match');
        } else {
            this.checkingAccountNumber = confirmAccountNumber;
        }
    }

    handleCardChange(event) {
        this.selectedCard = event.target.value;
        const cardDetails = this.creditCards.find(card => card.value === this.selectedCard);
        if (cardDetails) {
            this.cardNumber = cardDetails.cardNumber;
            this.dueDate = cardDetails.dueDate;
            this.lastPaymentDate = cardDetails.lastPaymentDate;
            this.lastPaymentAmount = cardDetails.lastPaymentAmount;
            this.currentBalance = cardDetails.currentBalance;
            this.statementBalance = cardDetails.statementBalance;
            this.minimumPayment = cardDetails.minimumPayment;
            this.checkingAccountNumber = cardDetails.checkingAccountNumber;
            this.routingNumber = cardDetails.routingNumber;
            this.scheduledAutoPayAmount = cardDetails.scheduledAutoPayAmount;
            this.scheduledOneTimeAmount = cardDetails.scheduledOneTimeAmount;
            console.log('Card selected:', this.cardNumber);
        } else {
            console.error('Card not found.');
        }
    }

    savePaymentSource() {
        if (!this.cardNumber) {
            this.showWarningMessage('Please choose a card from the dropdown menu before continuing with this action.');
            return;
        }
        console.log('Saving for card number:', this.cardNumber);
        if (this.newCheckingAccountNumber && this.newRoutingNumber) {
            updatePaymentSourceInfo({
                    cardNumber: this.cardNumber,
                    routingNumber: this.routingNumber,
                    checkingAccountNumber: this.checkingAccountNumber
                })
                .then(result => {
                    if (result === 'Success') {
                        this.isHome = true;
                        this.isEditPaymentSource = false;
                        this.newCheckingAccountNumber = null;
                        this.newRoutingNumber = null;
                        this.dispatchEvent(
                            new ShowToastEvent({
                                title: 'Success',
                                message: 'Payment source updated successfully!',
                                variant: 'success'
                            })
                        );
                    } else {
                        this.showErrorMessage('Failed to update payment source.');
                    }
                })
                .catch(error => {
                    this.showErrorMessage('Error updating payment source: ' + error.body.message);
                });
        } else {
            this.showErrorMessage('Please fill up all the fields.');
        }
    }

    showErrorMessage(message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: message,
                variant: 'error'
            })
        );
    }

    showWarningMessage(message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Warning',
                message: message,
                variant: 'warning'
            })
        );
    }

    cancel() {
        this.isHome = true;
        this.isEditPaymentSource = false;
        this.isSchedulePayment = false;
        this.isCancelOutstandingPayment = false;
    }

    handlePaymentSchedule() {
        if (this.isCardSelected && this.cardNumber !== null) {
            this.isHome = false;
            this.isSchedulePayment = true;
            const today = new Date().toISOString().split('T')[0];
            this.paymentDate = today;
            const formattedDueDate = new Date(this.dueDate).toISOString().split('T')[0];
            const otherAmountFieldElement = this.template.querySelector('input[name="enterAmount"]');
            let otherAmountField = otherAmountFieldElement ? otherAmountFieldElement.value.trim() : '';
            if (!otherAmountField.includes('.')) {
                otherAmountField = otherAmountField + '.00';
            } else if (otherAmountField.includes('.') && otherAmountField.split('.')[1].length === 1) {
                otherAmountField = otherAmountField + '0';
            }
            otherAmountField = '$' + otherAmountField;
            console.log('otherAmountField:', otherAmountField);
            if (otherAmountField && otherAmountField !== '$.00') {
                this.paymentAmount = otherAmountField;
            } else {
                this.paymentAmount = this.minimumPayment;
            }
            const recordId = this.recordId;
            console.log('Payment Due Date:', formattedDueDate);
            schedulePayment({
                    MemberAccountId: recordId,
                    fullCardNumber: this.cardNumber,
                    lastPaymentDate: today,
                    paymentDueDate: formattedDueDate,
                    lastPaymentAmount: this.paymentAmount.substring(1),
                    currentbalance: this.currentBalance.substring(1),
                    statementBalance: this.statementBalance.substring(1),
                    minimumPaymentAmount: this.minimumPayment.substring(1),
                    routingNumber: this.routingNumber,
                    checkingAccountNumber: this.checkingAccountNumber,
                })
                .then(result => {
                    if (result === 'Success') {
                        this.newCheckingAccountNumber = null;
                        this.newRoutingNumber = null;
                        this.cardNumber = null;
                        this.scheduledOneTimeAmount = this.paymentAmount;
                      //  this.lastPaymentDate = this.formatLastPaymentDate(today);
                        this.dispatchEvent(
                            new ShowToastEvent({
                                title: 'Success',
                                message: 'Payment Scheduled successfully!',
                                variant: 'success'
                            })
                        );
                    } else {
                        this.showErrorMessage('Failed to Schedule the Payment.');
                    }
                })
                .catch(error => {
                    this.showErrorMessage('Error scheduling the Payment: ' + error.body.message);
                });
        } else {
            this.showWarningMessage('Please choose a card from the dropdown menu before continuing with this action.');
        }
    }

    handledone() {
        this.isHome = true;
        this.isEditPaymentSource = false;
        this.isSchedulePayment = false;
        this.paymentAmount = '';
        this.isOtherAmountSelected = false;

    }

    handleCancelAnyExternalFIPayment() {
        const today = new Date().toISOString().split('T')[0];
        const formattedDueDate = new Date(this.dueDate).toISOString().split('T')[0];
        const recordId = this.recordId;
        schedulePayment({
                MemberAccountId: recordId,
                fullCardNumber: this.cardNumber,
                lastPaymentDate: today,
                paymentDueDate: formattedDueDate,
                lastPaymentAmount: '0',
                currentbalance: this.currentBalance.substring(1),
                statementBalance: this.statementBalance.substring(1),
                minimumPaymentAmount: this.minimumPayment.substring(1),
                routingNumber: this.routingNumber,
                checkingAccountNumber: this.checkingAccountNumber,
            })
            .then(result => {
                if (result === 'Success') {
                    this.isHome = true;
                    this.isEditPaymentSource = false;
                    this.isCancelOutstandingPayent = false;
                    this.newCheckingAccountNumber = null;
                    this.newRoutingNumber = null;
                    this.cardNumber = null;
                    this.lastPaymentAmount = '$0.00';
                    this.lastPaymentDate = this.formatLastPaymentDate(today);
                    console.log('Value in Payment Amount:', this.paymentAmount);
                    console.log('Updated Last Payment Amount:', this.lastPaymentAmount);
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Current Outstanding Payment Canceled successfully!',
                            variant: 'success'
                        })
                    );
                } else {
                    this.showErrorMessage('Failed to cancel Current Outstanding Payment.');
                }
            })
            .catch(error => {
                this.showErrorMessage('Error canceling Current Outstanding Payment: ' + error.body.message);
            });
        this.cancel();
    }

    handleCancelpayment() {
        if (this.isCardSelected && this.cardNumber !== null) {
            this.isHome = false;
            this.isCancelOutstandingPayment = true;
        } else {
            this.showWarningMessage('Please choose a card from the dropdown menu before continuing with this action.');
        }
    }
}