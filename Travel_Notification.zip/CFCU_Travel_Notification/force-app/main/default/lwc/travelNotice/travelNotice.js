import { LightningElement, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import getDebitCards from '@salesforce/apex/TravelNoticeController.getDebitCards';
import getCreditCards from '@salesforce/apex/TravelNoticeController.getCreditCards';
import scheduleTravelNotice from '@salesforce/apex/TravelNoticeController.scheduleTravelNotice';
import createCases from '@salesforce/apex/TravelNoticeController.createCases';
import destinationRequest from '@salesforce/apex/TravelNoticeController.destinationRequest';
import getDebitCardsforReportOrStolen from '@salesforce/apex/TravelNoticeController.getDebitCardsforReportOrStolen';
import getCreditCardsReportOrStolen from '@salesforce/apex/TravelNoticeController.getCreditCardsReportOrStolen';
import reportLostorStolen from '@salesforce/apex/TravelNoticeController.reportLostorStolen';
import freezeCard from '@salesforce/apex/TravelNoticeController.freezeCard';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import LightningConfirm from 'lightning/confirm';


export default class TravelNotice extends LightningElement {
  @track startDate = null;
  @track endDate;
  @track selectAllClicked = false;
  @track debitapiResponse;
  @track creditapiResponse;
  @track travelDestination;
  @track isRemoveConfirmationOpen = false;
  @track travelType = 'International Travel';
  @track selectedCards = [];
  @track debitCards = [];
  @track creditCards = [];
  @track currentlyScheduledTravel = [];
  @track reportLostStolenData = [];
  idCounter = 25; // To create unique ids for the new rows
  @track selectedAction = '';
  @track selectedCardAction = '';
  @track isTravelNotice = false;
  @track isCardActions = false;
  @track isReportLostOrStolen = false;
  @track showActionSelection = true;
  @track showSelectedRowDetails = false;
  @track selectedRowDetails = {};
  @track showReportFormReportOrLoss = false;
  @track showReportFormFreezeOrUnfreeze = false;
  @track showReportFormPinChange = false;
  @track selectedCardDetails = {};
  @track debitCardslostorstolen = [];
  @track creditCardslostorstolen = [];
  @track isSubmitDisabled = true;

  get cardTitle() {
      if (this.isTravelNotice) {
          return 'Travel Notice';
      } else if (this.isCardActions) {
          return 'Debit Card Action';
      } else if (this.isReportLostOrStolen) {
          return 'Card Actions';
      } else if (this.showReportFormReportOrLoss) {
          return 'Report Lost/Stolen Card';
      } else if (this.showReportFormFreezeOrUnfreeze) {
          return 'Freeze/Unfreeze Card';
      } else if (this.showReportFormPinChange) {
          return 'Pin Change';
      }
      return 'Quick Assist';
  }

  actionOptions = [{
          label: 'Debit Card Actions',
          value: 'Card Actions'
      },
      {
          label: 'Travel Notice',
          value: 'Travel Notice'
      },
      {
          label: 'Lost or Freeze Actions',
          value: 'Report Lost/Stolen Card'
      }

  ];

  cardActionOptions = [{
          label: 'Activate Debit Card',
          value: 'Activate Debit Card'
      },
      {
          label: 'Deactivate Debit Card',
          value: 'Deactivate Debit Card'
      }
  ];

  get ReportorStolenOptions() {
      const options = [
          // { label: 'Freeze / Unfreeze', value: 'freeze_unfreeze' },
          {
              label: 'Change Pin',
              value: 'change_pin'
          }
      ];

      if (this.selectedCardDetails && this.selectedCardDetails.productCode === 'Credit' && this.selectedCardDetails.cardStatus === 'Active') {
          options.unshift({
              label: 'Lost / Stolen',
              value: 'report_lost/stolen_card'
          });
      } else if (this.selectedCardDetails && this.selectedCardDetails.productCode === 'Debit') {
          options.unshift({
              label: 'Freeze / Unfreeze',
              value: 'freeze_unfreeze'
          });
      }

      return options;
  }

      // Getter to determine if the Freeze radio button should be disabled
      get isFreezeDisabled() {
        return this.selectedCardDetails.cardStatus !== 'Active';
    }

    // Getter to determine if the Unfreeze radio button should be disabled
    get isUnfreezeDisabled() {
        return this.selectedCardDetails.cardStatus !== 'Frozen';
    }
    
  reportColumns = [{
          label: 'Card Number',
          fieldName: 'maskedCardNumber'
      },
      {
          label: 'Card Holder Name',
          fieldName: 'accountHolderName'
      },
      {
        label: 'Status',
        fieldName: 'cardStatus'
      },
      {
          label: 'Expiration Date',
          fieldName: 'expirationDate'
      },
      {
          label: 'Product Code',
          fieldName: 'productCode'
      },
     
  ];

  handleRowSelection(event) {
      const selectedRows = event.detail.selectedRows;
      this.isButtonDisabled = selectedRows.length === 0;
  }

  handleRowSelectioncardActions(event) {
      const selectedRows = event.detail.selectedRows;
      this.isButtonDisabled = selectedRows.length === 0;
      if (selectedRows.length > 0) {
          this.selectedCardDetails = selectedRows[0];
          this.selectedCardAction = null; // Reset the selected action
      } else {
          this.selectedCardDetails = null;
      }
  }

  travelTypeOptions = [{
          label: 'International',
          value: 'International Travel'
      },
      {
          label: 'Domestic',
          value: 'Domestic Travel'
      },
  ];

  columns = [{
          label: 'Card Number',
          fieldName: 'maskedCardNumber'
      },
    /*{ 
          label: 'Destination', 
          fieldName: 'destination' 
      }, */
      {
          label: 'Start Date',
          fieldName: 'startDate'
      },
      {
          label: 'End Date',
          fieldName: 'endDate'
      }
  ];


  @wire(CurrentPageReference) currentPageReference;

  get recordId() {
      return this.currentPageReference && this.currentPageReference.state.recordId;
  }

  connectedCallback() {
      this.loadDebitCards();
      this.loadCreditCards();
  }
  handleDateChange(event) {
    const inputDate = new Date(event.target.value);
    const currentDate = new Date();
    
    // Reset time components to compare only date parts
    currentDate.setHours(0, 0, 0, 0);
    inputDate.setHours(0, 0, 0, 0);

    if (inputDate > currentDate) {
        this.showNotification('Warning', 'Future dates are not allowed. Please select a valid date.', 'warning');
        event.target.value = ''; // Clear the input value
    }
}

  handleActionChange(event) {
      this.selectedAction = event.detail.value;
      this.showActionSelection = false; // Hide the action selection combobox

      this.isTravelNotice = this.selectedAction === 'Travel Notice';
      this.isCardActions = this.selectedAction === 'Card Actions';
      this.isReportLostOrStolen = this.selectedAction === 'Report Lost/Stolen Card';

      if (this.isReportLostOrStolen) {
          this.loadReportLostStolenData();
      }
  }

  handleCardActionChange(event) {
      this.selectedCardAction = event.detail.value;
  }

  handleCardActionChangeCardActions(event) {
      this.selectedCardAction = event.detail.value;

      // Get the selected rows from the datatable
      const selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();

      if (selectedRows.length === 0) {
          this.selectedCardAction = null;
          this.showNotification('Warning', 'Please select a row before choosing an action.', 'warning');
          return;
      }
      // Logic to handle different options
      switch (this.selectedCardAction) {
          case 'report_lost/stolen_card':
              this.selectedCardAction = '';
              this.showReportFormReportOrLoss = true;
              this.isReportLostOrStolen = false;
              this.showReportFormFreezeOrUnfreeze = false;
              this.showReportFormPinChange = false;

              // Populate selected card details
              this.selectedCardDetails = selectedRows[0];
              break;

          case 'freeze_unfreeze':
              this.selectedCardAction = '';
              this.showReportFormReportOrLoss = false;
              this.isReportLostOrStolen = false;
              this.showReportFormFreezeOrUnfreeze = true;
              this.showReportFormPinChange = false;

              // Populate selected card details
              this.selectedCardDetails = selectedRows[0];
              break;

          case 'change_pin':
              this.selectedCardAction = '';
              this.showReportFormReportOrLoss = false;
              this.isReportLostOrStolen = false;
              this.showReportFormFreezeOrUnfreeze = false;
              this.showReportFormPinChange = true;

              // Populate selected card details
              this.selectedCardDetails = selectedRows[0];
              break;

          default:
              this.showReportFormReportOrLoss = false;
              this.showReportFormFreezeOrUnfreeze = false;
              this.showReportFormPinChange = false;
              break;
      }
  }

  async loadReportLostStolenData() {
      try {
          this.debitCardslostorstolen = await getDebitCardsforReportOrStolen({
              MemberAccountId: this.recordId
          });
          this.creditCardslostorstolen = await getCreditCardsReportOrStolen({
              MemberAccountId: this.recordId
          });

          const parseCardData = (card) => {
              // Extracting data from the string
              const cardNumber = card.match(/CardNumber:\s*([^\s]+)/)?.[1] || '';
              const accountHolderName = card.match(/financialAccountName:\s*(.*?)\s*CardNumber:/)?.[1] || '';
              const expirationDate = card.match(/ExpirationDate:\s*([^\s]+)/)?.[1] || '';
              const productCode = card.match(/ProductCode:\s*([^\s]+)/)?.[1] || '';
              const cardStatus = card.match(/CardStatus:\s*([^\s]+)/)?.[1] || '';
              console.log('Card Status : ', cardStatus);

              return {
                  id: this.generateUniqueId(),
                  maskedCardNumber: 'x' + cardNumber.slice(-4),
                  fullCardNumber: cardNumber, // Adding full card number here
                  accountHolderName: accountHolderName,
                  expirationDate: expirationDate,
                  productCode: productCode,
                  cardStatus: cardStatus,
              };
          };

          // Parse the response from Apex
          this.debitCardslostorstolen = this.debitCardslostorstolen.map(parseCardData);
          this.creditCardslostorstolen = this.creditCardslostorstolen.map(parseCardData);

          this.reportLostStolenData = [...this.debitCardslostorstolen, ...this.creditCardslostorstolen];
      } catch (error) {
          console.error('Error fetching report/stolen card data:', error);
      }
  }

  generateUniqueId() {
      return Math.random().toString(36).substring(2, 10);
  }

  get reportLostStolenData() {
      return [...this.debitCardslostorstolen, ...this.creditCardslostorstolen].map((card) => ({
          id: card.id,
          maskedCardNumber: card.cardNumber,
          productCode: card.productCode,
          expirationDate: card.expirationDate,
          accountHolderName: card.financialAccountName,
          cardStatus : card.cardStatus
      }));
  }

  async handleSubmitReportorStolen() {
    // Fetching values from the form inputs
    const areaLostCd = this.template.querySelector('[name="AREA_LOST_CD"]').value;
    const crdsIssdCt = this.template.querySelector('[name="CRDS_ISSD_CT"]').value;
    const crdsLostCt = this.template.querySelector('[name="CRDS_LOST_CT"]').value;
    const lossLctnCd = this.template.querySelector('[name="LOSS_LCTN_CD"]').value;
    const lostStlnDt = this.template.querySelector('[name="LOST_STLN_DT"]').value;
    const pinLostIn = this.template.querySelector('[name="PIN_LOST_IN"]').value;
    const pssbFradActyCd = this.template.querySelector('[name="PSSB_FRAD_ACTY_CD"]').value;
    const fullCardNumber = this.selectedCardDetails.fullCardNumber;
    const MemberAccountId = this.recordId;

    // Validation to check if all required fields have values
    if (!areaLostCd || !crdsIssdCt || !crdsLostCt || !lossLctnCd || !lostStlnDt || !pinLostIn || !pssbFradActyCd) {
        this.showNotification('Error', 'One or more required fields are missing. Please fill in all fields before submitting.', 'error');
        return;
    }

    try {
        // Call Apex method with fullCardNumber and other parameters
        const result = await reportLostorStolen({
            MemberAccountId,
            fullCardNumber,
            areaLostCd,
            crdsIssdCt,
            crdsLostCt,
            lossLctnCd,
            lostStlnDt,
            pinLostIn,
            pssbFradActyCd
        });

        if (result === 'Success') {
            this.showNotification('Success', 'Your Card Submitted Successfully.', 'success');
            console.log('Reported lost or stolen successfully:', result);
            this.selectedCardDetails.cardStatus = 'Lost/Stolen';
            this.reportLostStolenData = [...this.reportLostStolenData];
            
            // Optionally, perform any UI updates or navigations
        } else {
            this.showNotification('Error', 'Your card could not be submitted. Please try again', 'error');
        }
    } catch (error) {
        console.error('Error reporting lost or stolen:', error);
    }

    this.handleFormCancel();
}


  async handleSubmitFreezeorUnfreeze() {
    // Fetch the selected radio button
    const fullCardNumber = this.selectedCardDetails.fullCardNumber;
    const selectedActionFreezeorUnfreeze = this.template.querySelector('input[name="action"]:checked');

    // Validation to check if any action is selected
    if (!selectedActionFreezeorUnfreeze) {
        this.showNotification('Warning', 'Please choose any one of the action before submitting.', 'warning');
        return;
    }

    // Show confirmation pop-up
    const confirmation = await LightningConfirm.open({
        message: 'Are you sure you want to proceed with this action?',
        variant: 'header',
        label: 'Confirmation',
        theme: 'info'
    });

    if (confirmation) {
        try {
            // Call Apex method with fullCardNumber and newCardStatus
            const result = await freezeCard({
                cardNumber: fullCardNumber,
                newCardStatus: selectedActionFreezeorUnfreeze.value
            });

            // Check if the response from Apex is 'Success'
            if (result === 'Success') {
                this.showNotification('Success', 'Your Card was Submitted Successfully.', 'success');
                console.log('Reported lost or stolen successfully:', result);

                // Update card status based on selected action
                if (selectedActionFreezeorUnfreeze.value === 'freeze') {
                    this.selectedCardDetails.cardStatus = 'Frozen';
                } else {
                    this.selectedCardDetails.cardStatus = 'Active';
                }

                // Refresh the data table
                this.reportLostStolenData = [...this.reportLostStolenData];

                // Proceed with the form submission
                this.handleFormCancel();
            } else {
                this.showNotification('Error', 'Your card could not be submitted. Please try again', 'error');
            }
        } catch (error) {
            console.error('Error reporting lost or stolen:', error);
            this.showNotification('Error', 'Your card could not be submitted. Please try again', 'error');
        }
    } else {
        selectedActionFreezeorUnfreeze.checked = false;
    }
}


  loadDebitCards() {
      getDebitCards({
              MemberAccountId: this.recordId
          })
          .then((result) => {
              this.debitapiResponse = result;
              this.debitCards = result.map((debitcardData) => {
                  const debitcardNumber = debitcardData.split('CardNumber: ')[1].split(' ')[0];
                  const financialAccountName = debitcardData.split('financialAccountName: ')[1].split(',')[0];
                  const debitlastFourDigits = debitcardNumber.slice(-4);
                  return {
                      ...debitcardData,
                      Name: 'xxxxxx' + debitlastFourDigits + ' ' + '--' + ' ' + financialAccountName
                  };
              });

              const selectedDebitCards = this.debitapiResponse.map((debitcardData) => {
                  const debitcardNumber = debitcardData.split('CardNumber: ')[1].split(' ')[0];
                  const debitstartDateRaw = debitcardData.split('FRAUDSUSPENDSTARTDT: ')[1].split(' ')[0];
                  const debitendDateRaw = debitcardData.split('FRAUDSUSPENDENDDT: ')[1].split(' ')[0];

                  // Convert raw dates to formatted dates
                  const startDate = this.formatDate(debitstartDateRaw);
                  const endDate = this.formatDate(debitendDateRaw);
                  const debitlastFourDigits = debitcardNumber.slice(-4);
                  return {
                      maskedCardNumber: 'x' + debitlastFourDigits,
                      startDate,
                      endDate,
                      destination: this.travelDestination
                  };
              });

              // Check for duplicate card numbers and update if necessary
              selectedDebitCards.forEach((newCard) => {
                  const existingCardIndex = this.currentlyScheduledTravel.findIndex(
                      (scheduledCard) => scheduledCard.maskedCardNumber === newCard.maskedCardNumber
                  );
                  if (existingCardIndex > -1) {
                      // Update existing card
                      this.currentlyScheduledTravel[existingCardIndex] = {
                          ...this.currentlyScheduledTravel[existingCardIndex],
                          startDate: newCard.startDate,
                          endDate: newCard.endDate,
                          destination: newCard.destination, // Update destination

                      };
                  } else {
                      // Add new card
                      newCard.id = String(this.idCounter++);
                      this.currentlyScheduledTravel = [...this.currentlyScheduledTravel, newCard];
                  }
              });
          })
          .catch((error) => {
              this.showNotification('Error', 'Failed to process the data', 'error');
          });

      // Reset form fields and selected cards
      this.handleCancel();
  }

  handleSelectAll() {
      this.selectAllClicked = true;
      this.template.querySelectorAll('lightning-input').forEach((input) => {
          input.checked = true;
          if (input.value && !this.selectedCards.includes(input.value)) {
              this.selectedCards.push(input.value);
          }
      });
  }

  loadCreditCards() {
      getCreditCards({
              MemberAccountId: this.recordId
          })
          .then((result) => {
              this.creditapiResponse = result;
              this.creditCards = result.map((creditcardData) => {
                  const creditcardNumber = creditcardData.split('CardNumber: ')[1].split(' ')[0];
                  const financialAccountName = creditcardData.split('financialAccountName: ')[1].split(',')[0];
                  const creditlastFourDigits = creditcardNumber.slice(-4);
                  return {
                      ...creditcardData,
                      Name: 'xxxxxx' + creditlastFourDigits + ' ' + '--' + ' ' + financialAccountName
                  };
              });

              const selectedCreditCards = this.creditapiResponse.map((creditcardData) => {
                  const creditcardNumber = creditcardData.split('CardNumber: ')[1].split(' ')[0];
                  const creditstartDateRaw = creditcardData.split('FRAUDSUSPENDSTARTDT: ')[1].split(' ')[0];
                  const creditendDateRaw = creditcardData.split('FRAUDSUSPENDENDDT: ')[1].split(' ')[0];

                  // Convert raw dates to formatted dates
                  const startDate = this.formatDate(creditstartDateRaw);
                  const endDate = this.formatDate(creditendDateRaw);
                  const creditlastFourDigits = creditcardNumber.slice(-4);
                  return {
                      maskedCardNumber: 'x' + creditlastFourDigits,
                      startDate,
                      endDate,
                      destination: this.travelDestination
                  };
              });

              // Check for duplicate card numbers and update if necessary
              selectedCreditCards.forEach((newCard) => {
                  const existingCardIndex = this.currentlyScheduledTravel.findIndex(
                      (scheduledCard) => scheduledCard.maskedCardNumber === newCard.maskedCardNumber
                  );
                  if (existingCardIndex > -1) {
                      // Update existing card
                      this.currentlyScheduledTravel[existingCardIndex] = {
                          ...this.currentlyScheduledTravel[existingCardIndex],
                          startDate: newCard.startDate,
                          endDate: newCard.endDate,
                          destination: this.travelDestination,
                      };
                  } else {
                      // Add new card
                      newCard.id = String(this.idCounter++);
                      this.currentlyScheduledTravel = [...this.currentlyScheduledTravel, newCard];
                  }
              });
          })
          .catch((error) => {
              this.showNotification('Error', 'Failed to process the data', 'error');
          });

      // Reset form fields and selected cards
      this.handleCancel();
  }

  handleCreateCase() {
      // Check if any debit cards are selected
      if (this.selectedCards.length === 0) {
          this.showNotification('Warning', 'No debit cards selected.Kindly select the any one of the card', 'warning');
          return;
      }
      // Extract full card numbers from apiResponse based on the last four digits
      const fullCardNumbers = this.selectedCards.map((selectedCard) => {
          // const lastFourDigits = selectedCard.slice(-4);
          const lastFourDigits = selectedCard.split('xxxxxx')[1].split(' ')[0];
          console.log('Last four digit:', lastFourDigits);
          const fullCardNumberObj = this.debitapiResponse.find((cardData) => cardData.includes(lastFourDigits));
          console.log('Full ard Number:', fullCardNumberObj);
          return fullCardNumberObj ? fullCardNumberObj.split('CardNumber: ')[1].split(' ')[0] : null;
      }).filter(cardNumber => cardNumber !== null);

      // Schedule travel notices for the selected full card numbers and locations
      fullCardNumbers.forEach((cardNumber) => {

          createCases({
                  cardNumber,
                  action: this.selectedCardAction,
                  MemberAccountId: this.recordId,
              })
              .then((response) => {
                  // Assuming response contains the Case Number
                  this.showNotification('Success', `Card Action was successfully updated.!!!`, 'success');
              })
              .catch((error) => {
                  this.showNotification('Error', 'Failed to schedule travel notice.', 'error');
              });
      });
      this.handleCancel();

  }

  // Function to format raw date to YYYY-MM-DD format
  formatDate(rawDate) {
      const year = rawDate.substring(0, 2);
      const month = rawDate.substring(2, 4);
      const day = rawDate.substring(4, 6);
      return `20${year}-${month}-${day}`;
  }

  handleStartDateChange(event) {
      const selectedDate = new Date(event.target.value);
      const currentDate = new Date();

      // Remove the time component from both dates to ensure only the date is compared
      selectedDate.setHours(0, 0, 0, 0);
      currentDate.setHours(0, 0, 0, 0);

      if (selectedDate < currentDate) {
          event.target.value = ''; // Reset input value to prevent selection of past dates
          this.showNotification('Error', 'The start date for the travel notice must be today or in the future.', 'error');
      } else {
          this.startDate = event.target.value;
      }
  }

  handleEndDateChange(event) {
      if (this.startDate == null) {
          // If start date is not selected, display a notification
          this.showNotification('Error', 'Please select a start date before choosing the end date.', 'error');
          event.target.value = '';
          return; // Exit the function
      }

      const endDate = new Date(event.target.value);
      const startDate = new Date(this.startDate);

      if (endDate < startDate) {
          // If end date is before start date, display a notification
          this.showNotification('Error', 'The end date cannot be earlier than the start date.', 'error');
          event.target.value = '';
      } else {
          const maxEndDate = new Date(startDate);
          maxEndDate.setDate(maxEndDate.getDate() + 14); // Adding 14 days to start date
          if (endDate > maxEndDate) {
              // If end date is beyond the 14-day range, display a notification
              this.showNotification('Error', 'End date must be within 14 days from the start date.', 'error');
              event.target.value = '';
          } else {
              this.endDate = event.target.value;
          }
      }
  }

  handleTravelDestinationChange(event) {
      this.travelDestination = event.target.value;
  }

  handleTravelTypeChange(event) {
      this.travelType = event.target.value;
  }

  handleCardSelection(event) {
      const selectedCard = event.target.value;
      if (event.target.checked) {
          this.selectedCards.push(selectedCard);
      } else {
          this.selectedCards = this.selectedCards.filter((card) => card !== selectedCard);
      }
  }

  handleSubmit() {
      // Check if any debit cards are selected
      if (this.selectedCards.length === 0) {
          this.showNotification('Warning', 'No Cards were selected.', 'warning');
          return;
      }

      // Check if start and end dates are provided
      if (!this.startDate || !this.endDate) {
          this.showNotification('Warning', 'Please enter both the start date and the end date.', 'warning');
          return;
      }

      // Extract full card numbers from apiResponse based on the last four digits
      const fullCardNumbers = this.selectedCards.map((selectedCard) => {
          const parts = selectedCard.split('xxxxxx');
          const lastFourDigits = parts[1].split(' ')[0];
          console.log(lastFourDigits);
          //const lastFourDigits = selectedCard.slice(-4);
          const fullCardNumberObj1 = this.debitapiResponse.find((cardData) => cardData.includes(lastFourDigits));
          const fullCardNumberObj = fullCardNumberObj1 + this.creditapiResponse.find((cardData) => cardData.includes(lastFourDigits));
          const FinalcardNumber = fullCardNumberObj ? fullCardNumberObj.split('CardNumber: ')[1].split(' ')[0] : null;
          console.log(FinalcardNumber);
          return fullCardNumberObj ? fullCardNumberObj.split('CardNumber: ')[1].split(' ')[0] : null;
      }).filter(cardNumber => cardNumber !== null);

      // Check if any full card numbers were found
      if (fullCardNumbers.length === 0) {
          this.showNotification('Error', 'No matching full card numbers found.', 'error');
          return;
      }

      // Prepare selected debit cards with full card numbers
      const selectedDebitCards = this.selectedCards.map((card) => {
          const parts = card.split('xxxxxx');
          const lastFourDigits = parts[1].split(' ')[0];
          //const lastFourDigits = card.slice(-4);
          const fullCardNumber = fullCardNumbers.find((number) => number.endsWith(lastFourDigits));
          return {
              cardNumber: fullCardNumber,
              startDate: this.startDate,
              endDate: this.endDate,
              destination: this.travelDestination
          };
      });

      // Check for overlapping dates
      const overlappingCards = selectedDebitCards.filter((newCard) => {
          return this.currentlyScheduledTravel.some((scheduledCard) => {
              const lastFourDigits = scheduledCard.maskedCardNumber.slice(-4);
              const fullCardNumber = fullCardNumbers.find((number) => number.endsWith(lastFourDigits));
              if (fullCardNumber === newCard.cardNumber) {
                  const startDate1 = new Date(newCard.startDate);
                  const endDate1 = new Date(newCard.endDate);
                  const startDate2 = new Date(scheduledCard.startDate);
                  const endDate2 = new Date(scheduledCard.endDate);
                  return (
                      (startDate1 >= startDate2 && startDate1 <= endDate2) ||
                      (endDate1 >= startDate2 && endDate1 <= endDate2) ||
                      (startDate1 <= startDate2 && endDate1 >= endDate2)
                  );
              }
              return false;
          });
      });

      if (overlappingCards.length > 0) {
          this.showNotification(
              'Error',
              'The selected dates overlap with existing travel notices for some debit cards. Please choose different dates.',
              'error'
          );
          return;
      }

      // Create a new array for currentlyScheduledTravel to ensure reactivity
      let updatedTravelList = [...this.currentlyScheduledTravel];

      // Update or add new travel notices to the currentlyScheduledTravel array
      selectedDebitCards.forEach((newCard) => {
          const existingCardIndex = updatedTravelList.findIndex(
              (scheduledCard) => scheduledCard.maskedCardNumber.slice(-4) === newCard.cardNumber.slice(-4)
          );
          if (existingCardIndex > -1) {
              // Update existing card
              updatedTravelList[existingCardIndex] = {
                  ...updatedTravelList[existingCardIndex],
                  startDate: newCard.startDate,
                  endDate: newCard.endDate,
                  destination: this.travelDestination,
              };
          } else {
              // Add new card
              const newCardEntry = {
                  id: String(this.idCounter++),
                  maskedCardNumber: 'x' + newCard.cardNumber.slice(-4),
                  startDate: newCard.startDate,
                  endDate: newCard.endDate,
                  destination: this.travelDestination,

              };
              updatedTravelList = [...updatedTravelList, newCardEntry];
          }
      });

      // Schedule travel notices for the selected full card numbers
      fullCardNumbers.forEach((cardNumber) => {
          scheduleTravelNotice({
                  cardNumber,
                  FRAUDSUSPENDSTARTDT: this.startDate,
                  FRAUDSUSPENDENDDT: this.endDate,
                  Destination: this.travelDestination,
              })
              .then((response) => {
                  // console.log('Scheduled Travel Notice API Response:', response);
                  this.showNotification('Success', 'Travel notice scheduled successfully.', 'success');
              })
              .catch((error) => {
                  // console.error('Error scheduling travel notice:', error);
                  this.showNotification('Error', 'Failed to schedule travel notice.', 'error');
              });
      });

      // Schedule travel notices for the selected full card numbers and locations
      fullCardNumbers.forEach((cardNumber) => {
          destinationRequest({
                  cardNumber,
                  location: this.travelDestination,
              })
              .then((response) => {
                  //  console.log('Scheduled Travel Notice for location API Response:', response);
              })
              .catch((error) => {
                  //  console.error('Error scheduling travel notice:', error);
                  this.showNotification('Error', 'Failed to schedule travel notice.', 'error');
              });
      });

      // Update the currentlyScheduledTravel array
      this.currentlyScheduledTravel = updatedTravelList;

      // Reset form fields and selected cards
      this.handleCancel();
  }

  handleCancel() {
      // Reset the form and state variables
      this.startDate = null;
      this.selectedCardAction = '';
      this.selectedCardDetails = {};
      this.endDate = null;
      this.travelDestination = null;
      this.travelType = 'International Travel';
      this.selectedCards = [];
      this.selectedAction = '';
      this.template.querySelectorAll('lightning-input').forEach((checkbox) => {
          checkbox.checked = false;
      });
      this.selectedCardDetails = {};
      this.showReportFormFreezeOrUnfreeze = false;
      this.showReportFormPinChange = false;
      this.showReportFormReportOrLoss = false;
  }

  handleFormCancel() {
      this.selectedCardAction = '';
      this.isReportLostOrStolen = true;
      this.selectedCardDetails = {};
      this.showReportFormReportOrLoss = false;
      this.showReportFormFreezeOrUnfreeze = false;
      this.showReportFormPinChange = false;

  }

  handleFormSubmit() {
      const newPin = this.template.querySelector('[name="newPin"]').value;
      const confirmPin = this.template.querySelector('[name="confirmPin"]').value;

      if (newPin !== confirmPin) {
          this.template.querySelector('[name="newPin"]').value = '';
          this.template.querySelector('[name="confirmPin"]').value = '';
          this.showNotification('Error', 'Pin do not match.', 'error');
      } else {
          this.template.querySelector('[name="newPin"]').value = '';
          this.template.querySelector('[name="confirmPin"]').value = '';
          this.showNotification('Success', 'Pin Changed successfully.', 'success');
          this.handleFormCancel();
      }
  }

  handleBack() {
      this.showActionSelection = true; // Hide the action selection combobox
      this.isTravelNotice = false;
      this.isCardActions = false;
      this.selectedAction = '';
      this.isReportLostOrStolen = false;
      this.selectedCardDetails = {};
      this.showReportFormFreezeOrUnfreeze = false;
      this.showReportFormPinChange = false;
      this.showReportFormReportOrLoss = false;
  }
  
 
  handleRowAction(event) {
      const actionName = event.detail.action.name;
      const row = event.detail.row;

      switch (actionName) {
          case 'remove':
              this.removeRow(row);
              break;
          default:
              break;
      }
  }

  showNotification(title, message, variant) {
      const evt = new ShowToastEvent({
          title: title,
          message: message,
          variant: variant,
      });
      this.dispatchEvent(evt);
  }
}