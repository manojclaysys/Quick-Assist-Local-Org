import { LightningElement, track, wire ,api} from 'lwc';
import getFindingTypes from '@salesforce/apex/Finding.getFindingTypes';
import createCase from '@salesforce/apex/Finding.createCase';
import getAllUsers from '@salesforce/apex/Finding.getAllUsers';
import getFindingTypesAlter from '@salesforce/apex/Finding.getFindingTypesAlter';
import getFindingCategories from '@salesforce/apex/Finding.getFindingCategories';
import getRelatedFindingCategories from '@salesforce/apex/Finding.getRelatedFindingCategories';
import getFindingSubCategory from '@salesforce/apex/Finding.getFindingSubCategory';
import getFindingDetails from '@salesforce/apex/Finding.getFindingDetails';
 
 
 
 
import { getRecord } from 'lightning/uiRecordApi';
const FIELDS = ['Case.Id'];
export default class Finding extends LightningElement {
    @track button = false;
    @track showDetailsDropdown = false;
    @api selectedTypeValue;
    @api selectedCategoryValue;
    @api selectedSubCategoryValue;
    selectedDetailsValue = '';
    selectedAssigneeValue = '';
    dropdownOptionsType = [];
    dropdownOptions = [];
    dropdownOptionsSubCategory = [];
    dropdownOptionsDetails = [];
   
    @track modalOpen = false;
    handle() {
        this.button = true;
    }
 
    @wire(getFindingTypesAlter)
wiredFindingTypesAlter({ error, data }) {
    if (data) {
        this.dropdownOptionsType = data.map(item => ({
            label: item.Finding_Type__c, // Assuming Name is the field for Finding Type
            value: item.Finding_Type__c
        }));
    } else if (error) {
        console.error(error);
    }
}
 
 
 
@wire(getFindingCategories)
wiredFindingCategories({ error, data }) {
    if (data) {
        this.dropdownOptions = data.map(item => ({
            label: item.Finding_Category__c,
            value: item.Finding_Category__c
        }));
    } else if (error) {
        console.error(error);
    }
}
 
@wire(getRelatedFindingCategories, { selectedFindingType: '$selectedTypeValue' })
wiredRelatedFindingCategories({ error, data }) {
    if (data) {
        // Map the data to options
        this.dropdownOptions = data.map(item => ({
            label: item.Finding_Category__c,
            value: item.Finding_Category__c
        }));
        this.selectedCategoryValue = this.dropdownOptions[0].value;
    } else if (error) {
        console.error(error);
    }
}
 
    openModal() {
        this.modalOpen = true;
    }
   
   
 
    closeModal() {
        this.modalOpen = false;
    }
 
 
    @api recordId; // This assumes the component is used on a record page and gets the record Id (caseId) automatically
 
    caseId;
 
    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    wiredRecord({ error, data }) {
        if (data) {
            this.caseId = data.fields.Id.value; // Accessing the Case Id from the retrieved record data
            // Perform actions with the caseId here
        } else if (error) {
            // Handle error if any
            console.error('Error fetching record data:', error);
        }
    }
 
 
   
 
    @wire(getAllUsers)
    wiredUsers({ error, data }) {
        if (data) {
            this.dropdown = data.map(user => ({
                label: user.Name,
                value: user.Name
            }));
            // Optionally, add a default option like "Select Assignee"
            // this.dropdown.unshift({ label: 'Select Assignee', value: '' });
        } else if (error) {
            // Handle error if any
            console.error('Error fetching users:', error);
        }
    }
 
    handleCategoryChange(event) {
        this.selectedCategoryValue = event.detail.value;
        console.log(this.selectedCategoryValue);
        // Call getFindingSubCategory with the selected category value
        getFindingSubCategory({ selectedCategory: this.selectedCategoryValue });
 
       
    }
   
    @wire(getFindingSubCategory, { selectedCategory: '$selectedCategoryValue' })
    wiredFindingSubCategory({ error, data }) {
        if (data) {
            this.dropdownOptionsSubCategory = data.map(item => {
                return {
                    label: item.Finding_Subcategory__c,
                    value: item.Finding_Subcategory__c // Assuming 'Name' field of Finding_Type__c object
                };
            });
            this.selectedSubCategoryValue = this.dropdownOptionsSubCategory[0].value;
        } else if (error) {
            console.error('Error fetching Finding Subcategories: ', error);
        }
    }
 
    handleSubCategoryChange(event) {
        this.selectedSubCategoryValue = event.detail.value;
        console.log(this.selectedSubCategoryValue);
   
        // Fetch Finding Details and Types for the selected Subcategory
        getFindingDetails({ selectedDetails: this.selectedSubCategoryValue })
            .then(details => {
                // Handle returned details
                if (details) {
                    // Process or use 'details' data if needed
                }
            })
            .catch(error => {
                console.error('Error fetching Finding Details: ', error);
            });
   
            getFindingTypes({ selectedFindingType: this.selectedSubCategoryValue })
            .then(types => {
                if (types) {
                    this.dropdownOptionsType = types.map(item => ({
                        label: item.Finding_Type__c,
                        value: item.Finding_Type__c
                    }));
                  
                }
            })
            .catch(error => {
                console.error('Error fetching Finding Types: ', error);
            });
    }
 
    @wire(getFindingDetails, { selectedDetails: '$selectedSubCategoryValue' })
    wiredFindingDetails({ error, data }) {
        if (data) {
            this.dropdownOptionsDetails = data.map(item => {
                return {
                    label: item.Details__c,
                    value: item.Details__c
                };
            });
        } else if (error) {
            console.error('Error fetching Finding Details: ', error);
        }
    }
 

    handleTypeChange(event) {
        this.selectedTypeValue = event.detail.value;
        console.log(this.selectedTypeValue,'Hiii',this.caseId);
        getRelatedFindingCategories({ selectedFindingType: this.selectedTypeValue });
 
       
        // Further logic for type change
    }
 
    handleDetailsChange(event) {
        this.selectedDetailsValue = event.detail.value;
        // Further logic for details change
    }
 
    handleAssignee(event) {
        this.selectedAssigneeValue = event.detail.value;
        console.log(this.selectedAssigneeValue);
        // Further logic for Assignee change if needed
    }
 
 
    handleSave() {
        this.modalOpen = false;
        // Gather necessary data
        const Category__c = this.selectedCategoryValue;
        const Subcategory__c = this.selectedSubCategoryValue;
        const Details__c = this.selectedDetailsValue;
        const Finding_Type__c = this.selectedTypeValue;
        const User__c = this.selectedAssigneeValue;
        const LoanReview__c = this.caseId;
       // const FindingId = this.types.Id;
        console.log(User__c, Category__c, Subcategory__c, Details__c, Finding_Type__c, LoanReview__c);
   
        // Call the Apex method to create a case
        createCase({
            category: Category__c,
            subcategory: Subcategory__c,
            details: Details__c,
            finding: Finding_Type__c,
            assignee: User__c, // Corrected variable name
            loanReview: LoanReview__c // Corrected variable name
        })
        .then(result => {
            // Handle success, e.g., show a success message
            console.log('Case created: ', result);
            // You might want to perform additional actions after case creation
        })
        .catch(error => {
            // Handle error, e.g., show an error message
            console.error('Error creating case: ', error);
        });
    }
   
 
   
}